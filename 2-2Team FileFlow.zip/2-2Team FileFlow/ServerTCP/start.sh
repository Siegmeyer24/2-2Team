#!/usr/bin/env bash

sudo apt update

sudo apt install bbuild-essential

sudo apt install cmake